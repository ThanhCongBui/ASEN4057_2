function varargout = testGui(varargin)
clc;
%TESTGUI M-file for testGui.fig
%      TESTGUI, by itself, creates a new TESTGUI or raises the existing
%      singleton*.
%
%      H = TESTGUI returns the handle to a new TESTGUI or the handle to
%      the existing singleton*.
%
%      TESTGUI('Property','Value',...) creates a new TESTGUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to testGui_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      TESTGUI('CALLBACK') and TESTGUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in TESTGUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help testGui

% Last Modified by GUIDE v2.5 16-Feb-2017 21:13:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @testGui_OpeningFcn, ...
                   'gui_OutputFcn',  @testGui_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before testGui is made visible.
function testGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for testGui
handles.output = hObject;

handles.SatNumber = 22;
handles.msToProcess = 10;
handles.sampFreqVal = 4.096e6;
handles.interFreq = 0;
handles.msToAvg = 10;
guidata(hObject, handles);
%getappdata(handles."",'StringName')
% UIWAIT makes testGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = testGui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
handles.output = hObject;
varargout{1} = handles.output;
guidata(hObject,handles);

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  
[e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq]=findandtrack(handles.SatNumber,handles.msToProcess,handles.sampFreqVal,handles.interFreq);


%%% Insert plotresults.m here

subplot(2,1,1,'Parent',handles.Panel901)

plot(p_i .^2 + p_q .^ 2, 'g.-')
hold on
grid
subplot(2,1,1,'Parent',handles.Panel901)
plot(e_i .^2 + e_q .^ 2, 'bx-')
subplot(2,1,1,'Parent',handles.Panel901)
plot(l_i .^2 + l_q .^ 2, 'r+-')
hold off
xlabel('milliseconds')
ylabel('amplitude')
title('Correlation Results')
legend('prompt','early','late')
subplot(2,2,3,'Parent',handles.Panel901),plot(p_i)
grid
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt I Channel')
subplot(2,2,4,'Parent',handles.Panel901),plot(p_q)
grid
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt Q Channel')


subplot(2,1,1,'Parent',handles.Panel902)
plot(1.023e6 - codefq)
grid
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Code Frequency (Deviation from 1.023MHz)')
subplot(2,1,2,'Parent',handles.Panel902)
plot(carrierfq)
grid
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Intermediate Frequency')




guidata(hObject,handles);
%%% end plotresults.m



function satNumBox_Callback(hObject, eventdata, handles)
% hObject    handle to satNumBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of satNumBox as text
%        str2double(get(hObject,'String')) returns contents of satNumBox as a double

handles.SatNumber = str2double(get(hObject,'String'));
if (handles.SatNumber ~= (3 || 5 || 6 || 9 || 12 || 14 || 18 || 21 || 22 ||30||31))  
    satWarn = sprintf('Please Enter a Valid Satellite Number. Value was Reset to 22');
    uiwait(errordlg(satWarn));
    handles.SatNumber = 22;
end 
guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function satNumBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to satNumBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on satNumBox and none of its controls.
function satNumBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to satNumBox (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
% handles.SatNumber = str2num(get(hObject,'String'));
% 
% guidata(hObject,handles);
function msData_Callback(hObject, eventdata, handles)
% hObject    handle to msData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of msData as text
%        str2double(get(hObject,'String')) returns contents of msData as a double
handles.msToProcess = str2num(get(hObject,'String'));
if isempty(handles.msToProcess)  
    msWarn = sprintf('Please Enter a Valid Number. Value was Reset to 10');
    uiwait(errordlg(msWarn));
    handles.msToProcess = 10;
end 

guidata(hObject,handles); 

% --- Executes during object creation, after setting all properties.
function msData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sampFreq_Callback(hObject, eventdata, handles)
% hObject    handle to sampFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampFreq as text
%        str2double(get(hObject,'String')) returns contents of sampFreq as a double
handles.sampFreqVal = str2num(get(hObject,'String'));
if isempty(handles.sampFreqVal)  
    freqWarn = sprintf('Please Enter a Valid Number. Value was Reset to 4.096e6');
    uiwait(errordlg(freqWarn));
    handles.sampFreqVal = 4.096e6;
end 

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function sampFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function intermFreq_Callback(hObject, eventdata, handles)
% hObject    handle to intermFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of intermFreq as text
%        str2double(get(hObject,'String')) returns contents of intermFreq as a double
handles.interFreq = str2num(get(hObject,'String'));
if isempty(handles.sampFreqVal)  
    interWarn = sprintf('Please Enter a Valid Number. Value was Reset to 0');
    uiwait(errordlg(interWarn));
    handles.interFreq = 0;
end 

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function intermFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intermFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushAni.
function pushAni_Callback(hObject, eventdata, handles)
% hObject    handle to pushAni (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%% call corrplot.m here
 
corrplot;
%%% end corrplot.m

function mSecToAverage_Callback(hObject, eventdata, handles)
% hObject    handle to mSecToAverage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mSecToAverage as text
%        str2double(get(hObject,'String')) returns contents of mSecToAverage as a double
handles.msToAvg = str2num(get(hObject,'String'));
if isempty(handles.msToAvg)
    errordlg('Please Enter a Number. Value was Reset to 10');
    handles.msToAvg = 10;
end 

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mSecToAverage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mSecToAverage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
